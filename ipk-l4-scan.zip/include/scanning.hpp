/**
 * @file scanning.hpp
 * @brief Header file for scanning (sending and receiving packets and scanning ports)
 * @author Martin Mendl <x247581>
 * @date 2025-27-02
 */

#ifndef SCANNING_HPP
#define SCANNING_HPP

#include <iostream>
#include <string>
#include <netinet/in.h>
#include "arguments.hpp"

#define DATAGRAM_LEN 4096

// enum for port scan results
enum class ScanResult {
    OPEN,
    CLOSED,
    FILTERED,
    INCOMPLETE,
    UNKNOWN
};

inline const char* toString(ScanResult result) {
    switch (result) {
        case ScanResult::OPEN: return "OPEN";
        case ScanResult::CLOSED: return "CLOSED";
        case ScanResult::FILTERED: return "FILTERED";
        case ScanResult::INCOMPLETE: return "INCOMPLETE";
        case ScanResult::UNKNOWN: return "UNKNOWN";
        default: return "UNKNOWN";
    }
}

struct pseudoHeaderTCPv4 {
    u_int32_t sourceAdress;
    u_int32_t destAdress;
    u_int8_t tmp;
    u_int8_t protocol;
    u_int16_t tcp_length;
};

struct pseudoHeaderTCPv6 {
    struct in6_addr sourceAddress; // 128-bit source IP address
    struct in6_addr destAddress;   // 128-bit destination IP address
    uint32_t tcp_length;           // TCP segment length (excluding IPv6 header)
    uint8_t zero[3];               // Three bytes of zero padding
    uint8_t nextHeader;            // Next Header (should be IPPROTO_TCP)
};

class Socket {
    public:
        Socket(NetworkAdress sender, NetworkAdress receiver);
    protected:
        int sockfd;
        NetworkAdress sender;
        NetworkAdress receiver;
};

class SocketIpv4 : public Socket {
    public:
        SocketIpv4(NetworkAdress sender, NetworkAdress receiver);
        ~SocketIpv4();
        struct sockaddr_in getSender() const { return senderAddr; };
        struct sockaddr_in getReceiver() const { return receiverAddr; };
        int getSocket() const { return sockfd; };
    private:
        struct sockaddr_in senderAddr;
        struct sockaddr_in receiverAddr;
};

class SocketIpv6 : public Socket {
    public:
        SocketIpv6(NetworkAdress sender, NetworkAdress receiver);
        ~SocketIpv6();
        struct sockaddr_in6 getSender() const { return senderAddr; };
        struct sockaddr_in6 getReceiver() const { return receiverAddr; };
        int getSocket() const { return sockfd; };
    private:
        struct sockaddr_in6 senderAddr;
        struct sockaddr_in6 receiverAddr;
};

class SynPacket {
    public:
        SynPacket();
        ~SynPacket();
        void constructSynPacketIpv4(const SocketIpv4 &socket);
        void constructSynPacketIpv6(const SocketIpv6 &socket);
        char *getPacket() const { return datagram; };
    private:
        struct tcphdr *tcph;
        struct pseudoHeaderTCPv4 psh;
        struct pseudoHeaderTCPv6 psh6;
        char *datagram = new char[DATAGRAM_LEN]();
};

class Scanner {
    public:
        Scanner(NetworkAdress sender, NetworkAdress receiver, int timeout);
        ~Scanner();
        ScanResult scanPort();
    private:
        NetworkAdress sender;
        NetworkAdress receiver;
        SocketIpv4* socketip4;
        SocketIpv6* socketip6;
        SynPacket* synPacket;
        int timeout;
        ScanResult getResponseIpv4();
        ScanResult getResponseIpv6();
};



#endif // SCANNING_HPP