/**
 * @file network.cpp
 * @brief File for networking (sending and receiving packets and scenning ports)
 * @author Martin Mendl <x247581>
 * @date 2025-27-02
*/

#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h> 
#include <arpa/inet.h>
#include <unistd.h>
#include <stdexcept>
#include <netdb.h>
#include <netinet/ip.h>
#include <netinet/ip6.h>
#include <netinet/tcp.h>
#include <fcntl.h>
#include <thread>
#include "utils.hpp"
#include "scanning.hpp"

// Constructor for Socket class
Socket::Socket(NetworkAdress sender, NetworkAdress receiver) {
    this->sender = sender;
    this->receiver = receiver;
}

SocketIpv4::SocketIpv4(NetworkAdress sender, NetworkAdress receiver) : Socket(sender, receiver) {

    // Create socket
    sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_TCP);
    if (sockfd < 0) {
        throw std::runtime_error("Failed to create socket");
    }

    // set the socket for not blocking
    /*
    int flags = fcntl(sockfd, F_GETFL, 0);
    if (flags == -1) {
        throw std::runtime_error("Failed to get socket flags");
    }
    if (fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) == -1) {
        throw std::runtime_error("Failed to set socket flags");
    }
    */

    // bind the socket to the sender interface 
    if (setsockopt(sockfd, SOL_SOCKET, SO_BINDTODEVICE, sender.hostName.c_str(), sender.hostName.length()) < 0) {
        throw std::runtime_error("Failed to bind socket to interface");
    }

    // set the sender adress
    memset(&senderAddr, 0, sizeof(senderAddr));
    senderAddr.sin_family = AF_INET;
    senderAddr.sin_port = htons(sender.port);
    if (inet_pton(AF_INET, sender.ip.c_str(), &senderAddr.sin_addr) <= 0) {
        throw std::runtime_error("Invalid sender IP address");
    }

    // set the receiver adress
    memset(&receiverAddr, 0, sizeof(receiverAddr));
    receiverAddr.sin_family = AF_INET;
    receiverAddr.sin_port = htons(receiver.port);
    if (inet_pton(AF_INET, receiver.ip.c_str(), &receiverAddr.sin_addr) <= 0) {
        throw std::runtime_error("Invalid receiver IP address");
    }

}

// Destructor for SocketIpv4 class
SocketIpv4::~SocketIpv4() {
    std::cout << "Closing socket ipv4" << std::endl;
    //close(sockfd);
}

// Constructor for SocketIpv6 class
SocketIpv6::SocketIpv6(NetworkAdress sender, NetworkAdress receiver) : Socket(sender, receiver) {

    // Create socket
    sockfd = socket(AF_INET6, SOCK_RAW, IPPROTO_TCP);
    if (sockfd < 0) {
        throw std::runtime_error("Failed to create socket");
    }

    // set the socket for not blocking
    int flags = fcntl(sockfd, F_GETFL, 0);
    if (flags == -1) {
        throw std::runtime_error("Failed to get socket flags");
    }
    if (fcntl(sockfd, F_SETFL, flags | O_NONBLOCK) == -1) {
        throw std::runtime_error("Failed to set socket flags");
    }

    // bind the socket to the sender interface 
    if (setsockopt(sockfd, SOL_SOCKET, SO_BINDTODEVICE, sender.hostName.c_str(), sender.hostName.length()) < 0) {
        throw std::runtime_error("Failed to bind socket to interface");
    }

    // set the sender adress
    memset(&senderAddr, 0, sizeof(senderAddr));
    senderAddr.sin6_family = AF_INET6;
    senderAddr.sin6_port = htons(sender.port);
    if (inet_pton(AF_INET6, sender.ip.c_str(), &senderAddr.sin6_addr) <= 0) {
        throw std::runtime_error("Invalid sender IP address");
    }

    // set the receiver adress
    memset(&receiverAddr, 0, sizeof(receiverAddr));
    receiverAddr.sin6_family = AF_INET6;
    receiverAddr.sin6_port = htons(receiver.port);
    if (inet_pton(AF_INET6, receiver.ip.c_str(), &receiverAddr.sin6_addr) <= 0) {
        throw std::runtime_error("Invalid receiver IP address");
    }
}

// Destructor for SocketIpv6 class
SocketIpv6::~SocketIpv6() {
    std::cout << "Closing socket ipv6" << std::endl;
    //close(sockfd);
}

// Constructor for SynPacket class
SynPacket::SynPacket() {
    memset(&psh, 0, sizeof(psh));
    memset(&psh6, 0, sizeof(psh6));
    memset(datagram, 0, DATAGRAM_LEN);

}

// Construct the SYN packet for IPv4
void SynPacket::constructSynPacketIpv4(const SocketIpv4 &socket) {
    memset(datagram, 0, DATAGRAM_LEN);

    // Point to TCP header in datagram
    this->tcph = (struct tcphdr*)(datagram);
    memset(tcph, 0, sizeof(struct tcphdr));

    // TCP header setup
    tcph->th_sport = socket.getSender().sin_port;
    tcph->th_dport = socket.getReceiver().sin_port;
    tcph->th_seq = htonl(rand() % 4294967295); 
    tcph->th_ack = htonl(0);
    tcph->th_off = 5; 
    tcph->th_flags = TH_SYN;
    tcph->th_win = htons(5840);
    tcph->th_sum = 0;
    tcph->th_urp = 0;

    // Prepare pseudo-header
    memset(&psh, 0, sizeof(struct pseudoHeaderTCPv4));
    psh.sourceAdress = socket.getSender().sin_addr.s_addr;
    psh.destAdress = socket.getReceiver().sin_addr.s_addr;
    psh.tmp = 0;
    psh.protocol = IPPROTO_TCP;
    psh.tcp_length = htons(sizeof(struct tcphdr));

    // Calculate checksum
    int psize = sizeof(struct pseudoHeaderTCPv4) + sizeof(struct tcphdr);
    std::vector<char> psdgram(psize);
    memcpy(psdgram.data(), &psh, sizeof(struct pseudoHeaderTCPv4));
    memcpy(psdgram.data() + sizeof(struct pseudoHeaderTCPv4), tcph, sizeof(struct tcphdr));

    tcph->th_sum = checkSum(psdgram.data(), psize);

    for (unsigned long i = 0; i < sizeof(struct ip) + sizeof(struct tcphdr); ++i) {
        std::cout << std::hex << (0xFF & datagram[i]) << " ";
    }
    std::cout << std::dec;
    std::cout << "Datagram size: " << sizeof(struct tcphdr) << std::endl;

}

// Construct the SYN packet for IPv6
void SynPacket::constructSynPacketIpv6(const SocketIpv6 &socket) {

    // Point to the correct offset for TCP header (after "fake" IPv6 header)
    this->tcph = (struct tcphdr*)(datagram);

    // Configure TCP header fields
    tcph->th_sport = socket.getSender().sin6_port;
    tcph->th_dport = socket.getReceiver().sin6_port;
    tcph->th_seq = htonl(rand() % 4294967295);
    tcph->th_ack = htonl(0);
    tcph->th_off = 5; 
    tcph->th_flags = TH_SYN; 
    tcph->th_win = htons(5840); 
    tcph->th_sum = 0; 
    tcph->th_urp = 0; 

    // Prepare IPv6 pseudo header for checksum calculation
    memset(&psh6, 0, sizeof(psh6));
    psh6.sourceAddress = socket.getSender().sin6_addr;
    psh6.destAddress = socket.getReceiver().sin6_addr;
    psh6.tcp_length = htonl(sizeof(struct tcphdr));
    psh6.nextHeader = IPPROTO_TCP;

    // Create pseudo packet for checksum calculation
    int psize = sizeof(struct pseudoHeaderTCPv6) + sizeof(struct tcphdr);
    std::vector<char> psdgram(psize);

    memcpy(psdgram.data(), &psh6, sizeof(struct pseudoHeaderTCPv6));
    memcpy(psdgram.data() + sizeof(struct pseudoHeaderTCPv6), tcph, sizeof(struct tcphdr));

    // Calculate checksum
    tcph->th_sum = checkSum(psdgram.data(), psize);

    for (unsigned long i = 0; i < sizeof(struct ip6_hdr) + sizeof(struct tcphdr); ++i) {
        std::cout << std::hex << (0xFF & datagram[i]) << " ";
    }
    std::cout << std::dec;
    std::cout << "Datagram size: " << sizeof(struct tcphdr) << std::endl;
}

SynPacket::~SynPacket() {
    delete[] datagram;  
}

Scanner::Scanner(NetworkAdress sender, NetworkAdress receiver, int timeout) {
    this->sender = sender;
    this->receiver = receiver;
    this->timeout = timeout;

    if (sender.ipVer != receiver.ipVer) {
        throw std::runtime_error("Sender and receiver IP versions do not match");
    }

    // create the Socket
    if (sender.ipVer == IpVersion::IPV4) {
        socketip4 = new SocketIpv4(sender, receiver);
        synPacket = new SynPacket();   
        synPacket->constructSynPacketIpv4(*socketip4);
    } else {
        this->socketip6 = new SocketIpv6(sender, receiver);
        this->synPacket = new SynPacket();
        synPacket->constructSynPacketIpv6(*socketip6);
    }
}

// Method for senning the port
ScanResult Scanner::scanPort() {

    ScanResult rslt;
    const char *datagram = synPacket->getPacket();

    std::cout << "Sender name: " << sender.hostName << std::endl;
    std::cout << "Sender ip: " << sender.ip << std::endl;
    std::cout << "Port: " << sender.port << std::endl;
    std::cout << "Receiver name: " << receiver.hostName << std::endl;
    std::cout << "Receiver ip: " << receiver.ip << std::endl;
    std::cout << "Port: " << receiver.port << std::endl;

    // ipv4
    if (sender.ipVer == IpVersion::IPV4) {
        std::cout << "Socket: " << socketip4->getSocket() << std::endl;
        // first send
        struct sockaddr_in sockAddrIn = socketip4->getReceiver();

        if (sendto(socketip4->getSocket(), datagram, sizeof(struct tcphdr), 0, (struct sockaddr*)&sockAddrIn, sizeof(sockAddrIn)) < 0) {
            perror("sendto failed");
            throw std::runtime_error("Failed to send packet ipv4 1");
        }

        rslt = getResponseIpv4();
        if (rslt == ScanResult::UNKNOWN) {
            // second send
            if (sendto(socketip4->getSocket(), datagram, sizeof(struct tcphdr), 0, (struct sockaddr*)&sockAddrIn, sizeof(sockAddrIn)) < 0) {
                throw std::runtime_error("Failed to send packet ipv4 2");
            }
            rslt = getResponseIpv4();
            return (rslt == ScanResult::UNKNOWN) ? ScanResult::FILTERED : rslt;
        }
        return rslt;
    } 

    struct sockaddr_in6 sockAddrIn6 = socketip6->getReceiver();

    std::cout << "Socket: " << socketip6->getSocket() << std::endl;
    // ipv6
    if (sendto(socketip6->getSocket(), datagram, sizeof(struct tcphdr), 0, (struct sockaddr*)&sockAddrIn6, sizeof(sockAddrIn6)) < 0) {
        throw std::runtime_error("Failed to send packet ipv6 1");
    }

    rslt = getResponseIpv6();
    if (rslt == ScanResult::UNKNOWN) {
        // second send
        if (sendto(socketip6->getSocket(), datagram, sizeof(struct tcphdr), 0, (struct sockaddr*)&sockAddrIn6, sizeof(sockAddrIn6)) < 0) {
            throw std::runtime_error("Failed to send packet ipv6 2");
        }
        rslt = getResponseIpv6();
        return (rslt == ScanResult::UNKNOWN) ? ScanResult::FILTERED : rslt;
    }
    return rslt;
}

// Method to get the response for IPv4
ScanResult Scanner::getResponseIpv4() {

    char readBuffer[DATAGRAM_LEN];
    ssize_t recv_len = 0;
    
    //SocketIpv4* recvSocket = new SocketIpv4(sender, receiver);

    //std::cout << "Socket: " << recvSocket->getSocket() << std::endl;
    
    sockaddr_in in;
    socklen_t in_len = sizeof(in);

    int val = 1;
    if (setsockopt(socketip4->getSocket(), IPPROTO_IP, IP_HDRINCL, &val, sizeof(val)) < 0) {
        perror("Failed to set IP_HDRINCL");
        throw std::runtime_error("Failed to set IP_HDRINCL");
    }
    
    // Timeout handling
    //auto start = std::chrono::steady_clock::now();
    //auto timeout_ms = this->timeout;

    // Poll for incoming packets until timeout
    //do {
        std::cout << "waiting for a response" << std::endl;
        recv_len = recvfrom(socketip4->getSocket(), readBuffer, DATAGRAM_LEN, 0, (struct sockaddr *)&in, &in_len);
      //  if (recv_len > 0) break;
        //perror("recvfrom failed");
        //std::this_thread::sleep_for(std::chrono::milliseconds(10));
    //} while (std::chrono::duration_cast<std::chrono::milliseconds>(
     //            std::chrono::steady_clock::now() - start)
      //           .count() < timeout_ms);

    if (recv_len <= 0) {
        std::cout << "Timeout or failed to receive" << std::endl;
        return ScanResult::UNKNOWN;
    }

    // Parse incoming packet
    struct ip* ip_hdr = (struct ip*)readBuffer;
    int ip_header_len = ip_hdr->ip_hl * 4;

    if (recv_len < ip_header_len + 8) { // Minimum size for TCP RST packet
        std::cout << "Packet too small: " << recv_len << " bytes" << std::endl;
        return ScanResult::UNKNOWN;
    }

    if (ip_hdr->ip_p != IPPROTO_TCP) {
        std::cout << "Protocol mismatch: not TCP" << std::endl;
        return ScanResult::UNKNOWN;
    }

    struct tcphdr* tcp_hdr = (struct tcphdr*)(readBuffer + ip_header_len);

    // Ensure response is from the correct source and destination
    if (ip_hdr->ip_dst.s_addr != socketip4->getSender().sin_addr.s_addr) {
        std::cout << "Unexpected sender/receiver" << std::endl;
        return ScanResult::UNKNOWN;
    }

    // Check TCP flags
    if (tcp_hdr->th_flags == TH_RST) return ScanResult::CLOSED; // RST means closed port
    if (tcp_hdr->th_flags == TH_ACK || tcp_hdr->th_flags == TH_SYN) return ScanResult::OPEN; // SYN/ACK means open port

    std::cout << "Unexpected response" << std::endl;
    return ScanResult::UNKNOWN;
}

// Method for receiving the response for IPv6
ScanResult Scanner::getResponseIpv6() {

    char readBuffer[DATAGRAM_LEN];
    ssize_t recv_len = 0;

    // Timeout handling
    //auto start = std::chrono::steady_clock::now();
    //auto timeout_ms = this->timeout;

    // Poll for incoming packets until timeout
    //do {
    recv_len = recvfrom(socketip6->getSocket(), readBuffer, DATAGRAM_LEN, 0, NULL, NULL);
    //    if (recv_len > 0) break;
    //   std::this_thread::sleep_for(std::chrono::milliseconds(10));
    //} while (std::chrono::duration_cast<std::chrono::milliseconds>(
    //             std::chrono::steady_clock::now() - start)
     //            .count() < timeout_ms);

    if (recv_len <= 0) {
        std::cout << "Timeout or failed to receive" << std::endl;
        return ScanResult::UNKNOWN;
    }

    // Parse incoming packet
    struct ip6_hdr* ip_hdr = (struct ip6_hdr*)readBuffer;

    if ((unsigned long)recv_len < sizeof(struct ip6_hdr) + sizeof(struct tcphdr)) { // Minimum size for TCP RST packet
        std::cout << "Packet too small: " << recv_len << " bytes" << std::endl;
        return ScanResult::UNKNOWN;
    }

    if (ip_hdr->ip6_nxt != IPPROTO_TCP) {
        std::cout << "Protocol mismatch: not TCP" << std::endl;
        return ScanResult::UNKNOWN;
    }

    struct tcphdr* tcp_hdr = (struct tcphdr*)(readBuffer + sizeof(struct ip6_hdr));

    // Check TCP flags
    if (tcp_hdr->th_flags == TH_RST) return ScanResult::CLOSED; // RST means closed port
    if (tcp_hdr->th_flags == TH_ACK || tcp_hdr->th_flags == TH_SYN) return ScanResult::OPEN; // SYN/ACK means open port

    std::cout << "Unexpected response" << std::endl;
    return ScanResult::UNKNOWN;
}

// Destructor for Scanner class
Scanner::~Scanner() {
    delete synPacket;
}
    
