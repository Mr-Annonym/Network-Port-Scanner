/**
 * @file main.cpp
 * @brief Main file for the IPK project
 * @author Martin Mendl <x247581>
 * @date 2025-27-02
*/

#include <iostream>
#include "arguments.hpp"
#include "scanning.hpp"
#include "utils.hpp"

int main(int argc, char *argv[]) {
    // Parse arguments
    Settings settings(argc, argv);
    settings.representArguments();
    std::vector<NetworkAdress> interfaces = getNetworkInterfaces();
    representInterfaces(interfaces);
    NetworkAdress receiver, sender;

    // IPV4
    if (settings.isTargetIpv4()) {
        receiver = settings.getTargetIp4();
        sender = validateInterface(interfaces, settings.getInterface(), true);
        if (!sender.ip.empty()) {
            // TCP
            for (auto port : settings.getTCPports()) {
                // setup the sender and receiver
                receiver.port = port;
                // set the random number based on the time
                std::srand(static_cast<unsigned int>(std::time(nullptr)));
                sender.port = 49152 + (std::rand() % (65535 - 49152)); // choose a random port
                std::cout << "PORT -> " << sender.port << std::endl;
                // create the scanner
                Scanner scanner(sender, receiver, settings.getTimeout());
                // scan the port
                ScanResult result = scanner.scanPort();
                std::cout << "pre scan: Port " << port << ": " << toString(result) << std::endl;
                if (result == ScanResult::UNKNOWN) {
                    result = scanner.scanPort();
                    if (result == ScanResult::UNKNOWN) result = ScanResult::FILTERED;
                }
                // print the result
                std::cout << "Final Scan: Port " << port << ": " << toString(result) << std::endl;
                //delete &scanner; // just to be sure
            }

            // UDP TODO
        }
    }

    if (settings.isTargetIpv6()) {
        receiver = settings.getTargetIp6();
        sender = validateInterface(interfaces, settings.getInterface(), false);
        if (!sender.ip.empty()) {
            // TCP
            for (auto port : settings.getTCPports()) {
                // setup the sender and receiver
                receiver.port = port;
                sender.port = 49152 + (std::rand() % (65535 - 49152)); // choose a random port
                // create the scanner
                Scanner scanner(sender, receiver, settings.getTimeout());
                // scan the port
                ScanResult result = scanner.scanPort();
                std::cout << "pre scan: Port " << port << ": " << toString(result) << std::endl;
                if (result == ScanResult::UNKNOWN) {
                    result = scanner.scanPort();
                    if (result == ScanResult::UNKNOWN) result = ScanResult::FILTERED;
                }
                // print the result
                std::cout << "Final Scan: Port " << port << ": " << toString(result) << std::endl;
            }

            // UDP TODO
        }
    }


    return 0;
}